/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progassignment; //  package for this program

import java.util.ArrayList; // Import the ArrayList class 


import java.util.Scanner; // Import the Scanner class 




// Student class 
class Student {
    private final String studentId; // student id
    
    
    private final String name; // Name of the student
    
    private final int age; // Age of the student
    
    private final String email; // Email address of the student
    
    
    private final String course; // Course the student is doing

    
    
    
    
    
    
    
    // Constructor to initialize a new student with given details
    public Student(String studentId, String name, int age, String email, String course) {
        this.studentId = studentId;
        
        this.name = name;
        
        this.age = age;
        
        this.email = email;
        
        this.course = course;
        
    }

    //  method to return student ID
    
    public String getStudentId() { return studentId; }
    
    
    //  method to return student name
    
    public String getName() { return name; }
    
    
    //  method to return student age
    public int getAge() { return age; }
    
    
    //  method to return student email
    public String getEmail() { return email; }
    
    
    //  method to return student course
    public String getCourse() { return course; }
}

// StudentManager class 
class StudentManager {
    private final ArrayList<Student> students = new ArrayList<>(); // using array to store objects

    // svaing the objects to thye array
    public boolean saveStudent(Student student) {
        
        return students.add(student); // adding the student to the array
        
    }

    //  searching for a student by their ID
    public Student searchStudent(String studentId) {
        
        
        for (Student student : students) { 
            
            
            if (student.getStudentId().equals(studentId)) { // see if the ids match
                
                
                return student; // Return statement if the student is found
            }
        }
        return null; // Return null if no student is found with the given ID
    }

    //  delete a student by their ID
    public boolean deleteStudent(String studentId) {
        
        
        for (Student student : students) { // Iterate over each student in the list
            
            
            if (student.getStudentId().equals(studentId)) { // see if the ids match
                
                return students.remove(student); // Remove the students if the ids match
            }
        }
        return false; // Return false if the id does not match
    }

    // report of all students
    public ArrayList<Student> studentReport() {
        return new ArrayList<>(students); // displays the student list
    }

    
    public boolean isValidAge(int age) {
        return age >= 16; // the system checks to see if the students age is above 16
    }
}


public class Progassignment {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager(); 
        
        
        
        Scanner scanner = new Scanner(System.in); // using scanner

        while (true) { // using a loop to keep the system running 
            
            
            System.out.println("Menu:"); // Display the menu options
            
            System.out.println("1. Add Student");
            
            System.out.println("2. Search Student");
            
            System.out.println("3. Delete Student");
            
            System.out.println("4. View Student Report");
            
            System.out.println("5. Exit");
            
            System.out.print("Choose an option: "); // asks the user to type an option

            int choice = Integer.parseInt(scanner.nextLine()); 

            switch (choice) {
                
                
                case 1: // Option to add a student
                    System.out.print("Enter the student ID: ");
                    String studentId = scanner.nextLine(); // Read student ID

                    System.out.print("Enter the student name: ");
                    String name = scanner.nextLine(); // Read student name

                    int age; // Variable to store student age
                    while (true) { // Loop to validate age input
                        System.out.print("Enter the student age: ");
                        try {
                            age = Integer.parseInt(scanner.nextLine()); // Read and parse age
                            
                            
                            if (manager.isValidAge(age)) break; // Check if age is valid
                            
                            else System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                        } catch (NumberFormatException e) { // Handle invalid age input
                            
                            System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                        }
                    }

                    System.out.print("Enter the student email: ");
                    
                    String email = scanner.nextLine(); // Read student email

                    System.out.print("Enter the student course: ");
                    
                    String course = scanner.nextLine(); // Read student course

                    Student student = new Student(studentId, name, age, email, course); // Create a new Student object
                    
                    manager.saveStudent(student); // Save the student to the manager
                    
                    System.out.println("Student details have been successfully saved!");
                    break;

                    
                    
                case 2: // Option to search for a student
                    System.out.print("Enter the student id to search: ");
                    String searchId = scanner.nextLine(); // Read the ID to search

                    Student foundStudent = manager.searchStudent(searchId); // Search for the student
                    if (foundStudent != null) { // Check if student was found
                        
                        
                        
                        System.out.println("STUDENT ID: " + foundStudent.getStudentId());
                        System.out.println("STUDENT NAME: " + foundStudent.getName());
                        
                        
                        System.out.println("STUDENT AGE: " + foundStudent.getAge());
                        
                        
                        
                        
                        System.out.println("STUDENT EMAIL: " + foundStudent.getEmail());
                        System.out.println("STUDENT COURSE: " + foundStudent.getCourse());
                    } else {
                        System.out.println("Student with Student Id: " + searchId + " was not found!");
                    }
                    break;

                    
                    
                    
                    
                case 3: // Option to delete a student
                    System.out.print("Enter the student id to delete: ");
                    
                    
                    String deleteId = scanner.nextLine(); // Read the ID to delete

                    if (manager.deleteStudent(deleteId)) { // Attempt to delete the student
                        System.out.println("Student with Student Id: " + deleteId + " WAS deleted!");
                        
                        
                    } else {
                        System.out.println("Student with Student Id: " + deleteId + " was not found!");
                    }
                    break;

                    
                    
                    
                    
                case 4: // Option to view student report
                    ArrayList<Student> report = manager.studentReport(); // Get the list of all students
                    int count = 1; // Counter for student numbering
                    for (Student s : report) { // Iterate over each student
                        System.out.println("STUDENT " + count);
                        
                        
                        System.out.println("STUDENT ID: " + s.getStudentId());
                        
                        
                        System.out.println("STUDENT NAME: " + s.getName());
                        System.out.println("STUDENT AGE: " + s.getAge());
                        
                        
                        
                        System.out.println("STUDENT EMAIL: " + s.getEmail());
                        System.out.println("STUDENT COURSE: " + s.getCourse());
                        System.out.println();
                        count++; // Increment student counter
                    }
                    break;

                case 5: // Option to exit the application
                    System.out.println("Exiting application...");
                    scanner.close(); // Close the scanner
                    System.exit(0); // Terminate the program
                    break;

                default: // Handle invalid menu option
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}


/*code attributes:
Java JOptionPane, geeks for geeks, 2023 accessed from: https://www.geeksforgeeks.org/java-joptionpane/
Java strings ,w3schools,03/09/2024 accessed from: https://www.w3schools.com/java/java_strings.asp
java boolean,w3schools,03/09/2024 accessed from:https://www.w3schools.com/java/java_booleans.asp
java arraylist,w3schools,03/09/2024 accessed from:https://www.w3schools.com/java/java_arraylist.asp
public static void,stackoverflow,03/09/2024 accessed from:https://stackoverflow.com/questions/2390063/what-does-public-static-void-mean-in-java
java user input,w3schools,03/09/2024 accessed from:https://www.w3schools.com/java/java_user_input.asp
*/