/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progassignment;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

public class StudentManagerTest {
    private StudentManager studentManager;

    @Before
    public void setUp() {
        studentManager = new StudentManager();
    }

    @Test
    public void testSaveStudent() {
        Student student = new Student("002", "Jane Doe", 22, "jane@example.com", "Mathematics");
        assertTrue(studentManager.saveStudent(student));
        assertEquals(1, studentManager.studentReport().size());
    }

    @Test
    public void testSearchStudent() {
        Student student = new Student("003", "Alice Smith", 19, "alice@example.com", "Physics");
        studentManager.saveStudent(student);

        Student foundStudent = studentManager.searchStudent("003");
        assertNotNull(foundStudent);
        assertEquals("Alice Smith", foundStudent.getName());
    }

    @Test
    public void testSearchStudentNotFound() {
        Student foundStudent = studentManager.searchStudent("999");
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        Student student = new Student("004", "Bob Brown", 21, "bob@example.com", "Chemistry");
        studentManager.saveStudent(student);
        assertTrue(studentManager.deleteStudent("004"));
        assertEquals(0, studentManager.studentReport().size());
    }

    @Test
    public void testDeleteStudentNotFound() {
        assertFalse(studentManager.deleteStudent("999"));
    }

    @Test
    public void testStudentReport() {
        Student student1 = new Student("005", "Chris Green", 20, "chris@example.com", "Biology");
        Student student2 = new Student("006", "Dana White", 22, "dana@example.com", "Math");
        studentManager.saveStudent(student1);
        studentManager.saveStudent(student2);

        ArrayList<Student> report = studentManager.studentReport();
        assertEquals(2, report.size());
        assertEquals("Chris Green", report.get(0).getName());
        assertEquals("Dana White", report.get(1).getName());
    }
}
